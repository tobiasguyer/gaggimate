#pragma once
#ifndef GIT_VERSION_H
#define GIT_VERSION_H
#define BUILD_GIT_VERSION "v1.8.1-34-ga3848e62-dirty"
#define BUILD_TIMESTAMP "2026-05-27T10:32:34Z"
#endif
